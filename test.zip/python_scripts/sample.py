Name=input("Enter your Name \n")
Place=input("Enter place \n")
Details=print(f"My name is {Name} and staying in {Place}") # Using f method to display
Details=print("My name is {} and staying in {}" .format (Name,Place)) #Using format method to diaplay
User_ID=input(f"Enter user id of {Name} \n")
print(f"User id of {Name} is {User_ID}") #Using f method to display
print("User id of {} is {}" .format (Name,User_ID)) #Using format method to display

