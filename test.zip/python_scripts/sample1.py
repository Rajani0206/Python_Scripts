mylist=[]
print(mylist)
mylist=[10,20]
print(mylist)
